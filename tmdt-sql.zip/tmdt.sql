-- phpMyAdmin SQL Dump
-- version 4.7.9
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Sep 06, 2018 at 03:18 AM
-- Server version: 10.1.31-MariaDB
-- PHP Version: 7.0.28

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `tmdt`
--

-- --------------------------------------------------------

--
-- Table structure for table `product`
--

CREATE TABLE `product` (
  `id` int(10) NOT NULL,
  `product_skv` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `product_name` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  `product_msp` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `product_mt` text COLLATE utf8_unicode_ci NOT NULL,
  `product_date` datetime DEFAULT CURRENT_TIMESTAMP,
  `product_img` varchar(255) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `product`
--

INSERT INTO `product` (`id`, `product_skv`, `product_name`, `product_msp`, `product_mt`, `product_date`, `product_img`) VALUES
(41, '85847594', 'Dieu Hoa Tu  Lanh', 'asuwdx', 'asdasdasdsa', '2018-09-04 21:22:19', ',ao-khoac-cong-ty.jpg,ao-khoac-cong-ty-1.jpg,ao-khoac-cong-ty-2.jpg'),
(42, 'UHE984', 'Chổi Lau Nhà Sạch', '84uUJSE', 'xin chao cac bạn', '2018-09-04 21:34:52', ',11.jpg,21.jpg,32.jpg'),
(43, '47REW69A', 'Nước Lau Nhà', 'REWDASW', 'Nước Lau Nhà', '2018-09-04 21:44:46', ',12.jpg,22.jpg,33.jpg,42.jpg,5.jpg');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `product`
--
ALTER TABLE `product`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `product`
--
ALTER TABLE `product`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=44;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
